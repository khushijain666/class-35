//Create variables here

function preload()
{
	//load images here
dog.loadImage
 
}

function setup() {
	createCanvas(500,500);
  
}


function draw() {
  background()
    color.colorcode(46,139,87)

  if(keyWentDown(UP_ARROW)){
    writeStock(foodS);
    dog.addImage(dogHappy)
  }
  

drawSprites();
fill(red)
stroke()
  //add styles here
  dog=12
  happyDog=5
  database=2
  foodS=9
  foodStock=6
  foodStockdatabase.ref("Food")
  foodStock.on("value,readStock")

}



